var structsomm22_1_1peq_1_1_entry =
[
    [ "eventTime", "structsomm22_1_1peq_1_1_entry.html#a2cfe5ddea46cb9ab08d96ec9ae36ed3b", null ],
    [ "eventType", "structsomm22_1_1peq_1_1_entry.html#a7ec11d2afdbee6ed91f40584c319f923", null ],
    [ "pid", "structsomm22_1_1peq_1_1_entry.html#aec32162d9dc3fde2c76d766af522dae5", null ]
];