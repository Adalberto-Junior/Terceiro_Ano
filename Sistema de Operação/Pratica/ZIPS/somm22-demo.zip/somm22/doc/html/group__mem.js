var group__mem =
[
    [ "memAllocationPolicyAsString", "group__mem.html#gaf43cf359affd8134ca0ecd402708bec8", null ],
    [ "memInit", "group__mem.html#ga6f9aeb4b07942ca0cb75f0b7b7ad8086", null ],
    [ "memLog", "group__mem.html#ga89fd493f2885907f1972f687b4bcdc53", null ],
    [ "memPrint", "group__mem.html#ga9dd8f5e82d0c911129e350518494611a", null ],
    [ "memAlloc", "group__mem.html#gaac66dfbc15d6662df778334f79efd1f8", null ],
    [ "memFirstFitAlloc", "group__mem.html#gaa4e9b31f520af8c8166c92b119b6b7c6", null ],
    [ "memNextFitAlloc", "group__mem.html#ga9fc885022d7aabca6e53a3ddba862612", null ],
    [ "memBestFitAlloc", "group__mem.html#gafcf7ef4592b6e56c0a6ba3af82c60d2c", null ],
    [ "memWorstFitAlloc", "group__mem.html#gaa0d69bd1ed1fac83649caf3b8d4a2a9a", null ],
    [ "memFree", "group__mem.html#ga31bcf6fbb71fec31dbf1e7568fec0524", null ],
    [ "memGetBiggestHole", "group__mem.html#gaca42506dd57a3fa0646c1e140761d9a1", null ]
];