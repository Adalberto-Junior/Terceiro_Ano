var group__log =
[
    [ "logOpen", "group__log.html#gaaa0376b1844601698b62ddbb5609bc57", null ],
    [ "logOpen", "group__log.html#gab48223e3b22a084c6ef3a8c54094e8de", null ],
    [ "logClose", "group__log.html#ga3867390a24259dd76d0fd464fb3941e5", null ],
    [ "logGetStream", "group__log.html#ga7648c017796ec069897b3eff27d2e5eb", null ],
    [ "logPrint", "group__log.html#ga192a58145f2e4e50e400a8ca5504d8b3", null ],
    [ "logEvent", "group__log.html#gaf5a055014f873af60d9ebe77c5c010ae", null ]
];