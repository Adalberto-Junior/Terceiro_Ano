var namespacesomm22 =
[
    [ "mem", null, [
      [ "BlockRegister", "structsomm22_1_1mem_1_1_block_register.html", "structsomm22_1_1mem_1_1_block_register" ],
      [ "GlobalParameters", "structsomm22_1_1mem_1_1_global_parameters.html", "structsomm22_1_1mem_1_1_global_parameters" ],
      [ "Node", "structsomm22_1_1mem_1_1_node.html", "structsomm22_1_1mem_1_1_node" ]
    ] ],
    [ "pct", null, [
      [ "Entry", "structsomm22_1_1pct_1_1_entry.html", "structsomm22_1_1pct_1_1_entry" ],
      [ "Node", "structsomm22_1_1pct_1_1_node.html", "structsomm22_1_1pct_1_1_node" ]
    ] ],
    [ "peq", null, [
      [ "Entry", "structsomm22_1_1peq_1_1_entry.html", "structsomm22_1_1peq_1_1_entry" ],
      [ "Node", "structsomm22_1_1peq_1_1_node.html", "structsomm22_1_1peq_1_1_node" ]
    ] ],
    [ "Exception", "classsomm22_1_1_exception.html", "classsomm22_1_1_exception" ]
];