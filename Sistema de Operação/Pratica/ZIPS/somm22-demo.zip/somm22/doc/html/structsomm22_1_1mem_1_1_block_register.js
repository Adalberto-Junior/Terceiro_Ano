var structsomm22_1_1mem_1_1_block_register =
[
    [ "pid", "structsomm22_1_1mem_1_1_block_register.html#aec32162d9dc3fde2c76d766af522dae5", null ],
    [ "blockAddr", "structsomm22_1_1mem_1_1_block_register.html#aa81a891483c5da556023f1d08d1d94a8", null ],
    [ "blockSize", "structsomm22_1_1mem_1_1_block_register.html#ab6558f40a619c2502fbc24c880fd4fb0", null ]
];