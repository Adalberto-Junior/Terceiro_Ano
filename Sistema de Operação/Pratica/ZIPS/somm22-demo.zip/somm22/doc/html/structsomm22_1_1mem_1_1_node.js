var structsomm22_1_1mem_1_1_node =
[
    [ "data", "structsomm22_1_1mem_1_1_node.html#a4c181c9cdb2414529908bf12984f6283", null ],
    [ "next", "structsomm22_1_1mem_1_1_node.html#aa162dd1e0693188a22b1f13b9a2a0ef0", null ]
];