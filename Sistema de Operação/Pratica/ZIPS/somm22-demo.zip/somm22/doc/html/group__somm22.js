var group__somm22 =
[
    [ "Process Control Table (pct)", "group__pct.html", "group__pct" ],
    [ "Process Event Queue (peq)", "group__peq.html", "group__peq" ],
    [ "Memory Management (mem)", "group__mem.html", "group__mem" ],
    [ "Scheduling simulation", "group__sim.html", "group__sim" ],
    [ "Logging", "group__log.html", "group__log" ],
    [ "Exception", "group__exception.html", "group__exception" ],
    [ "Probing toolkit", "group__probing.html", "group__probing" ]
];