var namespaces_dup =
[
    [ "somm22", "namespacesomm22.html", null ]
];