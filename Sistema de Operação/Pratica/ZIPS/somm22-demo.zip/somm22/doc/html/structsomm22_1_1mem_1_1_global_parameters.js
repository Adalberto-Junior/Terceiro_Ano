var structsomm22_1_1mem_1_1_global_parameters =
[
    [ "policy", "structsomm22_1_1mem_1_1_global_parameters.html#a45589271ebcb65a64d7d9a99a2ac9b70", null ],
    [ "chunkSize", "structsomm22_1_1mem_1_1_global_parameters.html#a9f0ff12e35bd6d98a59245b0a01da521", null ],
    [ "memStart", "structsomm22_1_1mem_1_1_global_parameters.html#a278e5d28605731490bb61cb8d313a5f3", null ],
    [ "memSize", "structsomm22_1_1mem_1_1_global_parameters.html#a1d56e5453ce89b731040619bac587108", null ]
];