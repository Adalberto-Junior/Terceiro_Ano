var classsomm22_1_1_exception =
[
    [ "Exception", "classsomm22_1_1_exception.html#a5d4322ddb9317017f087de932a78ce50", null ],
    [ "what", "classsomm22_1_1_exception.html#a79009ed133fa02b942ddce8f0b987f3e", null ],
    [ "en", "classsomm22_1_1_exception.html#ae39cb450208e021f77f78933f93dd111", null ],
    [ "func", "classsomm22_1_1_exception.html#afc4e949c7b7d0ab565ecfb62c3380171", null ],
    [ "msg", "classsomm22_1_1_exception.html#a184b5dd9844bf6e022deb71044ff7f64", null ]
];