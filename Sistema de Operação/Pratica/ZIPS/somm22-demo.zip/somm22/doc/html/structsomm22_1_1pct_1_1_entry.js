var structsomm22_1_1pct_1_1_entry =
[
    [ "pid", "structsomm22_1_1pct_1_1_entry.html#aec32162d9dc3fde2c76d766af522dae5", null ],
    [ "arrivalTime", "structsomm22_1_1pct_1_1_entry.html#a167e4d9d3c967dfc829e53b7a4ebcd66", null ],
    [ "duration", "structsomm22_1_1pct_1_1_entry.html#a49f89df0e765bee620c337c51d397eff", null ],
    [ "addrSpaceSize", "structsomm22_1_1pct_1_1_entry.html#ad50a6f8c5f90713aa31b639773f1f3db", null ],
    [ "startTime", "structsomm22_1_1pct_1_1_entry.html#a776f35f97f4e03bed1685798da2dca92", null ],
    [ "memAddr", "structsomm22_1_1pct_1_1_entry.html#ab60de1d1ef1d41d38679c5cb1e79cef1", null ],
    [ "state", "structsomm22_1_1pct_1_1_entry.html#a46e7fb695f5e7ebad3c70e74294eae53", null ]
];